

        <Script src="javascript/jquery.js"></Script>
        <Script src="javascript/script.js"></Script>
        <Script src="javascript/script2.js"></Script>
</section>
</body>
</html>