
<body>
    <section class="container">
        <div class="nav">
            
            <div class="navlist">
                <a href="">Home</a>
                <a href="">My Tasks</a>
                <a href="">Add Task</a>
                <a href="">View Tasks</a>
                <a href="">Categories</a>
                <a href="">Notes</a>
                <a href="">Reminder</a>

            </div>
        </div>

        